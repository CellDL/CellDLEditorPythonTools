#===============================================================================
#
#  CellDL and bondgraph tools
#
#  Copyright (c) 2020 - 2025 David Brooks
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#===============================================================================

from typing import TYPE_CHECKING

#===============================================================================

from ..rdf import isLiteral, isNamedNode, namedNode, NamedNode, ResultType, uri_fragment
from ..rdf.namespace import XSD

if TYPE_CHECKING:
    from .model import BondgraphModel

#===============================================================================

LOCAL_MODEL_BASE = 'https://bg-rdf.org/models/local/'

#===============================================================================

def pretty_uri(uri: str|NamedNode|None) -> str:
#==============================================
    if uri is not None:
        uri_text: str = uri.value if isNamedNode(uri) else uri  # pyright: ignore[reportAssignmentType, reportAttributeAccessIssue]
        if uri_text.startswith(LOCAL_MODEL_BASE):
            pretty = uri_text[len(LOCAL_MODEL_BASE):]
        else:
            parts = uri_text.split('#', 1)
            if len(parts) > 1:
                pretty = '#' + parts[1]
            else:
                pretty = uri_text
    else:
        pretty = 'None'
    return pretty

#===============================================================================

def pretty_name(symbol: str, uri: str|NamedNode|None) -> str:
#============================================================
    return f'{symbol} ({pretty_uri(uri)})'

#===============================================================================

def optional_integer(value: ResultType, default: int|None=None) -> int|None:
#===========================================================================
    if (value is not None and isLiteral(value)
    and value.datatype == XSD.integer):     # pyright: ignore[reportAttributeAccessIssue]
        return int(value.value)             # pyright: ignore[reportAttributeAccessIssue]
    return default

def clean_name(name: str) -> str:
#=================================
    return name.replace(':', '_').replace('-', '_').replace('.', '_').replace(' ', '_')

#===============================================================================
#===============================================================================

class Labelled:
    def __init__(self, id: str, symbol: str|None=None, label: str|None=None):
        self.__id = id
        self.__uri = namedNode(id)
        if symbol is not None:
            self.__symbol = symbol
        else:
            self.__symbol = uri_fragment(id)
        self.__label = label

    def __str__(self) -> str:
        if self.__label is not None:
            return f'{self.__uri.value} ({self.__label})'
        return self.__uri.value

    def __eq__(self, other):
        return self.__id == other.__id

    @property
    def curie(self) -> str:
        return f':{uri_fragment(self.__id)}'

    @property
    def id(self) -> str:
        return self.__id

    @property
    def label(self) -> str|None:
        return self.__label

    @property
    def pretty_name(self) -> str:
        return pretty_name(self.__symbol, self.__id)

    @property
    def symbol(self) -> str:
        return self.__symbol

    @property
    def uri(self) -> NamedNode:
        return self.__uri       # pyright: ignore[reportReturnType]

#===============================================================================

class ModelElement(Labelled):
    def __init__(self,  model: 'BondgraphModel', id: str, symbol: str|None=None, label: str|None=None):
        super().__init__(id, symbol, label)
        self.__model = model

    @property
    def model(self):
        return self.__model

    def report_issue(self, issue: str):
        self.__model.report_issue(issue)

#===============================================================================
#===============================================================================
